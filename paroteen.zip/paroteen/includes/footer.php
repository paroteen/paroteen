<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<div class="footer" style="
margin: 10px 100px;
padding: 10px;
color: gray;
text-align: center;
border-top: 1px solid rgb(213, 213, 213);
">
    ParoTeen &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved.
</div>
