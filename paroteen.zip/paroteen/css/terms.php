<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();

include("config/connect.php");
include("includes/fetch_users_info.php");
include("includes/time_function.php");
include("includes/country_name_function.php");
include("includes/num_k_m_count.php");
if(!isset($_SESSION['Username'])){
   // header("location: ../index");
}

if (isset($_POST['note_submit'])) {
    $note_title = htmlentities($_POST['note_title'], ENT_QUOTES);
    $note_content = htmlentities($_POST['note_content'], ENT_QUOTES);
    $note_time = time();
    $note_id = rand(0,9999999)+time();
    $author_id = $_SESSION['id'];
    if (trim($note_title) == null) {
        $error_success_msg = "
<p id='error_msg' onclick='hideMsg()'>
Please write note title and try again.
</p>
";
    }elseif (trim($note_content) == null) {
        $error_success_msg = "
<p id='error_msg' onclick='hideMsg()'>
Please write note content and try again.
</p>
";
    }else{
    $newNote_sql = "INSERT INTO mynotepad 
(id,author_id,note_title,note_content,note_time)
VALUES
( :note_id, :author_id, :note_title, :note_content, :note_time)
    ";
    $newNote = $conn->prepare($newNote_sql);
    $newNote->bindParam(':note_id',$note_id,PDO::PARAM_INT);
    $newNote->bindParam(':author_id',$author_id,PDO::PARAM_INT);
    $newNote->bindParam(':note_title',$note_title,PDO::PARAM_STR);
    $newNote->bindParam(':note_content',$note_content,PDO::PARAM_STR);
    $newNote->bindParam(':note_time',$note_time,PDO::PARAM_INT);
    $newNote->execute();
    if ($newNote) {
        header("Location: main");
    }else{
        $error_success_msg = "
<p id='error_msg' onclick='hideMsg()'>
Error there was somthing wrong, Please try again.
</p>
";
        }
    }
}
?>

<html dir="<?php echo lang('html_dir'); ?>">
<head>
    <title>Terms | ParoTeen</title>
    <meta charset="UTF-8">
    <meta name="description" content="ParoTeen is a social network platform helps you meet new friends and stay connected with your family and with who you are interested anytime anywhere.">
    <meta name="keywords" content="social network,social media,ParoTeen,meet">
    <meta name="author" content="Flip Lab">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include "includes/head_imports_main.php";?>
    <style type="text/css">
        .noteContent{
            min-height: 196px;
            overflow-y: hidden;
            resize: none;
        }
    </style>
</head>
    <body onload="hide_notify()">
<!--=============================[ NavBar ]========================================-->
<?php include "includes/navbar_main.php"; ?>
<!--=============================[ Container ]=====================================-->
        <div align="center" style="margin-top: 65px;">
            <div class="white_div" style="text-align: <?php echo lang('textAlign'); ?>;">
            <u><center><h1 style="margin-top: 0;margin-bottom: 0;">Terms And Conditions</h1></center></u>
             
             <center><h3><b>Welcome to ParoTeen</b></h3></center>

            <center><p>ParoTeen is a social network website which is designed for legal acts and to increase means of communication globally and in institutions; a user minimum age is 13 years old.
            </p></center>
                    
             <center><h3><b>These Terms govern your use of ParoTeen</b></h3></center>
            <br>

             <center><p><b>Our mission is to give people the power to build community and bring the World closer together. To help advance this mission, we provide services described below to you:</p></b></center>
             <br>
             <p><b>Instant messaging:</b><br> We provide an instant messaging which works perfectly where you can choose one of your connections to chat with and while chatting you have a view about the person you are chatting with like if his/her account is verified ,if active and bio.</p>
            <br>
             <p><b>Verification badge:</b><br> A verified badge means “that <b>ParoTeen</b> has confirmed that this is the authentic account for the public figure, celebrity or global brand it represents.” Accounts representing well-known figures and brands are <b>verified</b> by green tick because they have a high likelihood of being impersonated.</p>
             <br>       
            <p><b>Connect you with people you care about:</b><br> We help you find and connect with people, groups and others that matter to you across the Facebook Products you use. We believe that our product is useful to connect people together and increase their relationship for free.</p>     
            <br>
            <p><b>Empower you to express yourself and communicate about what matters to you:</b><br>
                There are many ways to express yourself on ParoTeen and to communicate with friends, family and others about what matters to you for example using hashtag, sharing status updates, photos and stories across ParoTeen product.
            </p>
            <br>
            <p><b>Notes:</b><br> it allows you to make some notes so that you can remind yourself to worth paying attention to it.</p>
            <br>
            <p><b>Problem report:</b><br> we allow our community to report problems and help one another in order to build strong community and support our users. You can report some account if it abuse other user’s rights and we remove that account from our community after making some investigations.</p>
            </div>
        </div>
<!--=============================[ Footer ]========================================-->
<?php include("../includes/footer.php"); ?>
<script>
$('#noteTitle').maxlength();
    var acc = document.getElementsByClassName("dropdown_div_accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].onclick = function(){
            this.classList.toggle("active");
            this.nextElementSibling.classList.toggle("show");
        }
    }
$('.noteContent').each(function () {
  this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;text-align: <?php echo lang('textAlign'); ?>;');
}).on('input', function () {
  this.style.height = 'auto';
  this.style.height = (this.scrollHeight) + 'px';
})
function hideMsg(){
    $('#error_msg').fadeOut('slow');
    $('#success_msg').fadeOut('slow');
}
</script>
    </body>
</html>