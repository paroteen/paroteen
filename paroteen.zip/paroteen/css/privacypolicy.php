<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();

include("config/connect.php");
include("includes/fetch_users_info.php");
include("includes/time_function.php");
include("includes/country_name_function.php");
include("includes/num_k_m_count.php");
if(!isset($_SESSION['Username'])){
    header("location: ../index");
}

if (isset($_POST['note_submit'])) {
    $note_title = htmlentities($_POST['note_title'], ENT_QUOTES);
    $note_content = htmlentities($_POST['note_content'], ENT_QUOTES);
    $note_time = time();
    $note_id = rand(0,9999999)+time();
    $author_id = $_SESSION['id'];
    if (trim($note_title) == null) {
        $error_success_msg = "
<p id='error_msg' onclick='hideMsg()'>
Please write note title and try again.
</p>
";
    }elseif (trim($note_content) == null) {
        $error_success_msg = "
<p id='error_msg' onclick='hideMsg()'>
Please write note content and try again.
</p>
";
    }else{
    $newNote_sql = "INSERT INTO mynotepad 
(id,author_id,note_title,note_content,note_time)
VALUES
( :note_id, :author_id, :note_title, :note_content, :note_time)
    ";
    $newNote = $conn->prepare($newNote_sql);
    $newNote->bindParam(':note_id',$note_id,PDO::PARAM_INT);
    $newNote->bindParam(':author_id',$author_id,PDO::PARAM_INT);
    $newNote->bindParam(':note_title',$note_title,PDO::PARAM_STR);
    $newNote->bindParam(':note_content',$note_content,PDO::PARAM_STR);
    $newNote->bindParam(':note_time',$note_time,PDO::PARAM_INT);
    $newNote->execute();
    if ($newNote) {
        header("Location: main");
    }else{
        $error_success_msg = "
<p id='error_msg' onclick='hideMsg()'>
Error there was somthing wrong, Please try again.
</p>
";
        }
    }
}
?>

<html dir="<?php echo lang('html_dir'); ?>">
<head>
    <title>Privacy Policy | ParoTeen</title>
    <meta charset="UTF-8">
    <meta name="description" content="ParoTeen is a social network platform helps you meet new friends and stay connected with your family and with who you are interested anytime anywhere.">
    <meta name="keywords" content="social network,social media,ParoTeen,meet">
    <meta name="author" content="Flip Lab">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include "../includes/head_imports_main.php";?>
    <style type="text/css">
        .noteContent{
            min-height: 196px;
            overflow-y: hidden;
            resize: none;
        }
    </style>
</head>
    <body onload="hide_notify()">
<!--=============================[ NavBar ]========================================-->
<?php include "../includes/navbar_main.php"; ?>
<!--=============================[ Container ]=====================================-->
        <div align="center" style="margin-top: 65px;">
            <div class="white_div" style="text-align: <?php echo lang('textAlign'); ?>;">
            <u><center><h1 style="margin-top: 0;margin-bottom: 0;">Privacy Policy</h1></center></u>
             
             <center><h3><b>Welcome to ParoTeen</b></h3></center>

            <center><p>This policy describes the information we process to support ParoTeen and other Flip Lab products
            </p></center>
                    
             <center><h3><b>What kind of information do we collect?</b></h3></center>
            <br>

             <center><p><b>To provide ParoTeen product we must process information about you. The types of information we correct depend on how you use ParoTeen. You can learn how to access and delete information we corrected by visiting paroTeen settings</p></b></center>
             <p><b><i>Things you and others do and provide</i></b></p>
             <br>
             <p><b> Information and content you provide.</b><br> We collect the content, communications and other information you provide when you use our Products, including when you sign up for an account, create or share content, and message or communicate with others. This can include information in or about the content you provide (like metadata), such as the date a file was created.</p>
            <br>
             <p><b>Data with special protections:</b><br> You can choose to provide information in your ParoTeen Profile fields like posting photos on it and be only one to see them or you can choose to share with your friends.</p>
             <br>       
            <p><b>Networks and connections.</b><br> We collect information about the people, Pages, accounts and hashtags and how you interact with them across our Products, such as people you communicate with.</p>     
            <br>
            <p><b>Your usage.</b><br> We collect information of how you use our Products, such as the types of content you view or engage with; the features you use; the actions you take; the people or accounts you interact with; and the time, frequency and duration of your activities. For example, we log when you're using and have last used ParoTeen, and what posts and other content you view on ParoTeen.
            </p>
            <br>
            <p><b>Things others do and information they provide about you.</b><br> We also receive and analyze content, communications and information that other people provide when they use ParoTeen. This can include information about you, such as when others share or comment on a photo of you, send a message to you, or upload, sync or import your contact information. to it.</p>
                  </div>
<!--=============================[ Footer ]========================================-->
<?php include("../includes/footer.php"); ?>
<script>
$('#noteTitle').maxlength();
    var acc = document.getElementsByClassName("dropdown_div_accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].onclick = function(){
            this.classList.toggle("active");
            this.nextElementSibling.classList.toggle("show");
        }
    }
$('.noteContent').each(function () {
  this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;text-align: <?php echo lang('textAlign'); ?>;');
}).on('input', function () {
  this.style.height = 'auto';
  this.style.height = (this.scrollHeight) + 'px';
})
function hideMsg(){
    $('#error_msg').fadeOut('slow');
    $('#success_msg').fadeOut('slow');
}
</script>
    </body>
</html>